package com.foamyguy.bluefruit_playground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ModulesListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modules_list);
    }

    public void startToneGeneratorActivity(View view) {
        Intent toneGenIntent = new Intent(this, ToneActivity.class);
        startActivity(toneGenIntent);

    }

    public void startTemperatureActivity(View view) {
        Intent temperatureIntent = new Intent(this, TemperatureActivity.class);
        startActivity(temperatureIntent);
    }

    public void startLightActivity(View view) {
        Intent lightIntent = new Intent(this, LightActivity.class);
        startActivity(lightIntent);

    }

    public void startButtonsActivity(View view) {
        Intent buttonsIntent = new Intent(this, ButtonsActivity.class);
        startActivity(buttonsIntent);
    }

    public void startAccelerometerActivity(View view) {
        Intent accelerometerIntent = new Intent(this, AccelerometerActivity.class);
        startActivity(accelerometerIntent);
    }
}
