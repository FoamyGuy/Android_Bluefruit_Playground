package com.foamyguy.bluefruit_playground;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.jjoe64.graphview.series.DataPoint;

import java.text.NumberFormat;

public class LightActivity extends Activity {
    private final String TAG = LightActivity.class.getSimpleName();
    BroadcastReceiver lightDataReceiver;
    TextView lightTxt;
    ProgressBar lightProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_light);

        lightTxt = (TextView) findViewById(R.id.lightTxt);
        lightProgress = (ProgressBar) findViewById(R.id.lightProgress);

        IntentFilter lightDataFilter = new IntentFilter(BluefruitService.ACTION_LIGHT_DATA_AVAILABLE);
        lightDataReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int light = intent.getIntExtra("light", 0);
                Log.i(TAG, "onReceive temperature data: " + light);
                lightProgress.setProgress(light);
                lightTxt.setText(""+light);
            }
        };
        registerReceiver(lightDataReceiver, lightDataFilter);

        Intent enableLightNotify = new Intent(BluefruitService.ACTION_ENABLE_LIGHT_NOTIFY);
        sendBroadcast(enableLightNotify);
    }


    @Override
    protected void onStop() {
        super.onStop();

        Intent i = new Intent(BluefruitService.ACTION_DISABLE_LIGHT_NOTIFY);
        sendBroadcast(i);
        Log.d(TAG, "sent disable light notify");

        try {
            unregisterReceiver(lightDataReceiver);
        } catch (IllegalArgumentException e) {
            // Receiver was not registered
            e.printStackTrace();
        }
    }
}
