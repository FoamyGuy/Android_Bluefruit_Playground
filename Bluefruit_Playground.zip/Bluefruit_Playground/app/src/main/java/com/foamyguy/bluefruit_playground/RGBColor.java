package com.foamyguy.bluefruit_playground;

public class RGBColor {
    public int r = 0;
    public int g = 0;
    public int b = 0;
}
